# Flutter App — FOOT ANALYTICS

Estrutura inicial para o aplicativo mobile.

Crie o projeto com:
`flutter create .`

Depois conecte as telas à API em:
`http://10.0.2.2:3000/api` (emulador Android)
ou ao IP local do computador em um dispositivo físico.
