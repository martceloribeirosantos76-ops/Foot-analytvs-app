import 'package:flutter/material.dart';

void main() => runApp(const FootAnalyticsApp());

class FootAnalyticsApp extends StatelessWidget {
  const FootAnalyticsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FOOT ANALYTICS',
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('FOOT ANALYTICS')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Text('Análises de Futebol', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          SizedBox(height: 20),
          Card(
            child: ListTile(
              title: Text('Jogos de hoje'),
              subtitle: Text('Selecione uma partida para ver estatísticas e FOOT SCORE.'),
              trailing: Icon(Icons.chevron_right),
            ),
          ),
          Card(
            child: ListTile(
              title: Text('Times'),
              subtitle: Text('Desempenho, forma e métricas avançadas.'),
              trailing: Icon(Icons.chevron_right),
            ),
          ),
          Card(
            child: ListTile(
              title: Text('Jogadores'),
              subtitle: Text('Estatísticas e comparação individual.'),
              trailing: Icon(Icons.chevron_right),
            ),
          ),
        ],
      ),
    );
  }
}
